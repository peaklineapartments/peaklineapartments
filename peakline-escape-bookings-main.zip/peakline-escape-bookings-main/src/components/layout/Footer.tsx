import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Phone, MessageCircle, Instagram, MapPin, Mail } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  const handleCall = () => {
    window.open('tel:+255715245377', '_self');
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/255715245377', '_blank');
  };

  const handleInstagram = () => {
    window.open('https://instagram.com/peaklineappartments', '_blank');
  };

  const handleEmail = () => {
    window.open('mailto:peaklineappartments@gmail.com', '_self');
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="col-span-1 md:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mb-4"
            >
              <h3 className="text-2xl font-bold bg-gold-gradient bg-clip-text text-transparent mb-2">
                Peakline Apartments
              </h3>
              <p className="text-primary-foreground/80 max-w-md">
                Experience luxury and comfort in our modern apartments. Your home away from home 
                with exceptional service and unmatched amenities.
              </p>
            </motion.div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4 text-accent">Quick Links</h4>
            <div className="space-y-2">
              <Link to="/" className="block text-primary-foreground/80 hover:text-accent transition-colors">
                Home
              </Link>
              <Link to="/deals" className="block text-primary-foreground/80 hover:text-accent transition-colors">
                Deals
              </Link>
              <Link to="/gallery" className="block text-primary-foreground/80 hover:text-accent transition-colors">
                Gallery
              </Link>
              <Link to="/about" className="block text-primary-foreground/80 hover:text-accent transition-colors">
                About Us
              </Link>
              <Link to="/contact" className="block text-primary-foreground/80 hover:text-accent transition-colors">
                Contact Us
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4 text-accent">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-primary-foreground/80">
                <Phone className="h-4 w-4" />
                <span>+255 715 245 377</span>
              </div>
              <div className="flex items-center space-x-2 text-primary-foreground/80">
                <Mail className="h-4 w-4" />
                <span>peaklineappartments@gmail.com</span>
              </div>
              <div className="flex items-center space-x-2 text-primary-foreground/80">
                <MapPin className="h-4 w-4" />
                <span>Dar es Salaam, Tanzania</span>
              </div>
            </div>
          </div>
        </div>

        {/* Social Media & Copyright */}
        <div className="border-t border-primary-foreground/20 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex space-x-2 mb-4 md:mb-0">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCall}
              className="hover:bg-primary-foreground/10 text-primary-foreground hover:text-accent"
            >
              <Phone className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleWhatsApp}
              className="hover:bg-primary-foreground/10 text-primary-foreground hover:text-accent"
            >
              <MessageCircle className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleInstagram}
              className="hover:bg-primary-foreground/10 text-primary-foreground hover:text-accent"
            >
              <Instagram className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-primary-foreground/60 text-sm">
            © {currentYear} Peakline Apartments. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;