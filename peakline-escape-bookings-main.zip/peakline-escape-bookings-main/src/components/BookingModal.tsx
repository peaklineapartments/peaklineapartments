import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Users, DollarSign, CreditCard, Smartphone, Building, CheckCircle } from 'lucide-react';
import { format, addDays, differenceInDays } from 'date-fns';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from '@/hooks/use-toast';

interface Apartment {
  id: string;
  name: string;
  bedrooms: number;
  pricePerNight: number;
  description: string;
}

const apartments: Apartment[] = [
  { id: 'A1', name: 'Apartment A1', bedrooms: 2, pricePerNight: 60, description: 'Luxury 2-bedroom with city view' },
  { id: 'A2', name: 'Apartment A2', bedrooms: 2, pricePerNight: 60, description: 'Modern 2-bedroom with balcony' },
  { id: 'A3', name: 'Apartment A3', bedrooms: 2, pricePerNight: 60, description: 'Spacious 2-bedroom with garden view' },
  { id: 'B1', name: 'Apartment B1', bedrooms: 2, pricePerNight: 60, description: 'Contemporary 2-bedroom suite' },
  { id: 'B2', name: 'Apartment B2', bedrooms: 2, pricePerNight: 60, description: 'Elegant 2-bedroom with terrace' },
  { id: 'B3', name: 'Apartment B3', bedrooms: 1, pricePerNight: 40, description: 'Cozy 1-bedroom apartment' }
];

const paymentMethods = [
  { id: 'bank', name: 'Bank Transfer', icon: Building },
  { id: 'cash', name: 'Cash on Site', icon: DollarSign },
  { id: 'mobile', name: 'Mobile Wallet', icon: Smartphone },
  { id: 'card', name: 'Credit/Debit Card', icon: CreditCard }
];

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState(1);
  const [selectedApartment, setSelectedApartment] = useState<string>('');
  const [checkInDate, setCheckInDate] = useState<Date | undefined>();
  const [checkOutDate, setCheckOutDate] = useState<Date | undefined>();
  const [paymentMethod, setPaymentMethod] = useState<string>('');
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    whatsapp: '',
    specialRequests: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const selectedApartmentData = apartments.find(apt => apt.id === selectedApartment);
  const nights = checkInDate && checkOutDate ? differenceInDays(checkOutDate, checkInDate) : 0;
  const totalPrice = selectedApartmentData && nights > 0 ? selectedApartmentData.pricePerNight * nights : 0;

  const handleNextStep = () => {
    if (step < 4) setStep(step + 1);
  };

  const handlePrevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmitBooking = async () => {
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Create booking summary
    const bookingDetails = {
      apartment: selectedApartmentData,
      checkIn: checkInDate ? format(checkInDate, 'PPP') : '',
      checkOut: checkOutDate ? format(checkOutDate, 'PPP') : '',
      nights,
      totalPrice,
      paymentMethod: paymentMethods.find(pm => pm.id === paymentMethod)?.name,
      customer: customerInfo
    };

    // In a real app, this would send an email via API
    console.log('Booking submitted:', bookingDetails);
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    
    toast({
      title: "Booking Submitted Successfully!",
      description: "You will receive a confirmation email shortly.",
    });
  };

  const resetModal = () => {
    setStep(1);
    setSelectedApartment('');
    setCheckInDate(undefined);
    setCheckOutDate(undefined);
    setPaymentMethod('');
    setCustomerInfo({
      name: '',
      email: '',
      phone: '',
      whatsapp: '',
      specialRequests: ''
    });
    setIsSubmitted(false);
    setIsSubmitting(false);
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  if (isSubmitted) {
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="max-w-md">
          <div className="text-center py-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="mx-auto mb-4 w-16 h-16 bg-accent rounded-full flex items-center justify-center"
            >
              <CheckCircle className="w-8 h-8 text-accent-foreground" />
            </motion.div>
            <h3 className="text-xl font-semibold mb-2">Booking Submitted!</h3>
            <p className="text-muted-foreground mb-6">
              Your booking has been submitted. Please wait to hear back within 24 hours. 
              If it is urgent, please call or WhatsApp +255715245377.
            </p>
            <Button onClick={handleClose} variant="gold" size="lg">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Book Your Stay</DialogTitle>
          <div className="flex items-center space-x-2 mt-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className={`flex-1 h-2 rounded-full ${i <= step ? 'bg-accent' : 'bg-muted'}`} />
            ))}
          </div>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-semibold mb-4">Select Your Apartment</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {apartments.map((apartment) => (
                  <Card 
                    key={apartment.id}
                    className={`cursor-pointer transition-all hover:shadow-card ${
                      selectedApartment === apartment.id ? 'ring-2 ring-accent shadow-glow' : ''
                    }`}
                    onClick={() => setSelectedApartment(apartment.id)}
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{apartment.name}</CardTitle>
                          <CardDescription>{apartment.description}</CardDescription>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-accent">${apartment.pricePerNight}</div>
                          <div className="text-sm text-muted-foreground">per night</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-2 text-muted-foreground">
                        <Users className="w-4 h-4" />
                        <span>{apartment.bedrooms} bedroom{apartment.bedrooms > 1 ? 's' : ''}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <h3 className="text-lg font-semibold">Select Your Dates</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label>Check-in Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !checkInDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {checkInDate ? format(checkInDate, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={checkInDate}
                        onSelect={(date) => {
                          setCheckInDate(date);
                          if (date && checkOutDate && date >= checkOutDate) {
                            setCheckOutDate(addDays(date, 1));
                          }
                        }}
                        disabled={(date) => date < new Date()}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <Label>Check-out Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !checkOutDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {checkOutDate ? format(checkOutDate, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={checkOutDate}
                        onSelect={setCheckOutDate}
                        disabled={(date) => !checkInDate || date <= checkInDate}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {nights > 0 && selectedApartmentData && (
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <span>Total for {nights} night{nights > 1 ? 's' : ''}:</span>
                      <span className="text-2xl font-bold text-accent">${totalPrice}</span>
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <h3 className="text-lg font-semibold">Payment Method</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {paymentMethods.map((method) => {
                  const Icon = method.icon;
                  return (
                    <Card
                      key={method.id}
                      className={`cursor-pointer transition-all hover:shadow-card ${
                        paymentMethod === method.id ? 'ring-2 ring-accent shadow-glow' : ''
                      }`}
                      onClick={() => setPaymentMethod(method.id)}
                    >
                      <CardContent className="flex items-center space-x-3 pt-6">
                        <Icon className="w-6 h-6 text-accent" />
                        <span className="font-medium">{method.name}</span>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <h3 className="text-lg font-semibold">Your Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo(prev => ({...prev, name: e.target.value}))}
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo(prev => ({...prev, email: e.target.value}))}
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo(prev => ({...prev, phone: e.target.value}))}
                    placeholder="+255..."
                  />
                </div>
                <div>
                  <Label htmlFor="whatsapp">WhatsApp Number</Label>
                  <Input
                    id="whatsapp"
                    value={customerInfo.whatsapp}
                    onChange={(e) => setCustomerInfo(prev => ({...prev, whatsapp: e.target.value}))}
                    placeholder="+255... (if different from phone)"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="requests">Special Requests</Label>
                <Textarea
                  id="requests"
                  value={customerInfo.specialRequests}
                  onChange={(e) => setCustomerInfo(prev => ({...prev, specialRequests: e.target.value}))}
                  placeholder="Any special requests or requirements..."
                  rows={3}
                />
              </div>

              {/* Booking Summary */}
              <Card className="bg-muted/50">
                <CardHeader>
                  <CardTitle className="text-lg">Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span>Apartment:</span>
                    <span className="font-medium">{selectedApartmentData?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Check-in:</span>
                    <span>{checkInDate ? format(checkInDate, 'PPP') : ''}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Check-out:</span>
                    <span>{checkOutDate ? format(checkOutDate, 'PPP') : ''}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Payment:</span>
                    <span>{paymentMethods.find(pm => pm.id === paymentMethod)?.name}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between font-bold text-lg">
                    <span>Total:</span>
                    <span className="text-accent">${totalPrice}</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={step === 1 ? handleClose : handlePrevStep}
          >
            {step === 1 ? 'Cancel' : 'Previous'}
          </Button>

          {step < 4 ? (
            <Button
              onClick={handleNextStep}
              disabled={
                (step === 1 && !selectedApartment) ||
                (step === 2 && (!checkInDate || !checkOutDate || nights <= 0)) ||
                (step === 3 && !paymentMethod)
              }
              variant="gold"
            >
              Next
            </Button>
          ) : (
            <Button
              onClick={handleSubmitBooking}
              disabled={
                !customerInfo.name || !customerInfo.email || !customerInfo.phone || isSubmitting
              }
              variant="cta"
              className="min-w-[120px]"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Booking'}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BookingModal;