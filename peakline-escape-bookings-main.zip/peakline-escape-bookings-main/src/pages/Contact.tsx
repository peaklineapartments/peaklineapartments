import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Phone, MessageCircle, Instagram, MapPin, Mail, Clock, Send, CheckCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const Contact = () => {
  const [feedbackForm, setFeedbackForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const contactMethods = [
    {
      icon: Phone,
      title: 'Call Us',
      description: 'Speak directly with our team',
      value: '+255 715 245 377',
      action: () => window.open('tel:+255715245377', '_self'),
      actionLabel: 'Call Now'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      description: 'Quick messaging for urgent inquiries',
      value: '+255 715 245 377',
      action: () => window.open('https://wa.me/255715245377', '_blank'),
      actionLabel: 'Open WhatsApp'
    },
    {
      icon: Instagram,
      title: 'Instagram',
      description: 'Follow us for updates and photos',
      value: '@peaklineappartments',
      action: () => window.open('https://instagram.com/peaklineappartments', '_blank'),
      actionLabel: 'Follow Us'
    },
    {
      icon: Mail,
      title: 'Email',
      description: 'Send us detailed inquiries',
      value: 'peaklineappartments@gmail.com',
      action: () => window.open('mailto:peaklineappartments@gmail.com', '_self'),
      actionLabel: 'Send Email'
    }
  ];

  const businessHours = [
    { day: 'Monday - Friday', hours: '8:00 AM - 10:00 PM' },
    { day: 'Saturday', hours: '9:00 AM - 10:00 PM' },
    { day: 'Sunday', hours: '9:00 AM - 8:00 PM' },
    { day: 'Emergency Support', hours: '24/7 Available' }
  ];

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    // In a real app, this would send the feedback via API
    console.log('Feedback submitted:', feedbackForm);

    toast({
      title: "Feedback Submitted!",
      description: "Thank you for your feedback. We'll get back to you soon.",
    });

    // Reset form
    setFeedbackForm({
      name: '',
      email: '',
      subject: '',
      message: ''
    });

    setIsSubmitting(false);
  };

  const handleGoogleMaps = () => {
    // Replace with actual coordinates of Peakline Apartments
    window.open('https://maps.google.com/?q=Dar+es+Salaam,+Tanzania', '_blank');
  };

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-luxury-gradient bg-clip-text text-transparent">
            Contact Us
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Get in touch with our friendly team. We're here to help with reservations, 
            questions, or any assistance you need.
          </p>
        </motion.div>

        {/* Contact Methods */}
        <section className="mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-8 text-center"
          >
            Get In Touch
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactMethods.map((method, index) => {
              const Icon = method.icon;
              return (
                <motion.div
                  key={method.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-card transition-all duration-300 group">
                    <CardHeader className="text-center">
                      <div className="mx-auto mb-4 w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                        <Icon className="w-8 h-8 text-accent" />
                      </div>
                      <CardTitle className="text-lg">{method.title}</CardTitle>
                      <CardDescription>{method.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="text-center">
                      <p className="font-medium mb-4 text-foreground">{method.value}</p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={method.action}
                      >
                        {method.actionLabel}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Business Hours & Location */}
        <section className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Business Hours */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-6 h-6 text-accent" />
                    <CardTitle className="text-xl">Business Hours</CardTitle>
                  </div>
                  <CardDescription>
                    Our support team is available during these hours
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {businessHours.map((schedule, index) => (
                      <div key={index} className="flex justify-between items-center py-2 border-b border-border last:border-0">
                        <span className="font-medium">{schedule.day}</span>
                        <span className="text-muted-foreground">{schedule.hours}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Location */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-6 h-6 text-accent" />
                    <CardTitle className="text-xl">Our Location</CardTitle>
                  </div>
                  <CardDescription>
                    Find us in the heart of Dar es Salaam
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Address</h4>
                      <p className="text-muted-foreground">
                        Peakline Apartments<br />
                        Downtown District<br />
                        Dar es Salaam, Tanzania
                      </p>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={handleGoogleMaps}
                    >
                      <MapPin className="w-4 h-4 mr-2" />
                      View on Google Maps
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* Feedback Form */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Send className="w-6 h-6 text-accent" />
                <CardTitle className="text-2xl">Send Us Feedback</CardTitle>
              </div>
              <CardDescription>
                We value your feedback and suggestions. Let us know how we can improve your experience.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleFeedbackSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="feedback-name">Name *</Label>
                    <Input
                      id="feedback-name"
                      value={feedbackForm.name}
                      onChange={(e) => setFeedbackForm(prev => ({...prev, name: e.target.value}))}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="feedback-email">Email *</Label>
                    <Input
                      id="feedback-email"
                      type="email"
                      value={feedbackForm.email}
                      onChange={(e) => setFeedbackForm(prev => ({...prev, email: e.target.value}))}
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="feedback-subject">Subject *</Label>
                  <Input
                    id="feedback-subject"
                    value={feedbackForm.subject}
                    onChange={(e) => setFeedbackForm(prev => ({...prev, subject: e.target.value}))}
                    placeholder="What is this regarding?"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="feedback-message">Message *</Label>
                  <Textarea
                    id="feedback-message"
                    value={feedbackForm.message}
                    onChange={(e) => setFeedbackForm(prev => ({...prev, message: e.target.value}))}
                    placeholder="Tell us your thoughts, suggestions, or any issues you'd like to report..."
                    rows={5}
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  variant="cta" 
                  size="lg" 
                  className="w-full md:w-auto"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Send className="w-5 h-5 mr-2 animate-pulse" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Send Feedback
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.section>

        {/* Emergency Contact */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <Card className="bg-destructive/5 border-destructive/20">
            <CardContent className="p-8 text-center">
              <h3 className="text-xl font-semibold mb-4 text-destructive">Emergency Support</h3>
              <p className="text-muted-foreground mb-6">
                For urgent matters outside business hours, you can reach our emergency support line.
              </p>
              <Button 
                variant="destructive" 
                size="lg"
                onClick={() => window.open('tel:+255715245377', '_self')}
              >
                <Phone className="w-5 h-5 mr-2" />
                Emergency: +255 715 245 377
              </Button>
            </CardContent>
          </Card>
        </motion.section>
      </div>
    </div>
  );
};

export default Contact;