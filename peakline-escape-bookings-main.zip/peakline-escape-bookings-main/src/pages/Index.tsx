import React, { useState } from 'react';
import { motion } from 'framer-motion';
import HeroSlider from '@/components/HeroSlider';
import BookingModal from '@/components/BookingModal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Star, Wifi, Car, Coffee, Dumbbell, Shield } from 'lucide-react';

const Index = () => {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const amenities = [
    { icon: Wifi, title: 'Free WiFi', description: 'High-speed internet throughout the property' },
    { icon: Car, title: 'Free Parking', description: 'Secure parking available for all guests' },
    { icon: Coffee, title: 'Coffee Bar', description: 'Complimentary coffee and tea service' },
    { icon: Dumbbell, title: 'Fitness Center', description: 'Modern gym with state-of-the-art equipment' },
    { icon: Shield, title: '24/7 Security', description: 'Round-the-clock security and surveillance' },
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      rating: 5,
      comment: "Absolutely wonderful stay! The apartment was clean, modern, and had everything we needed."
    },
    {
      name: "Michael Chen",
      rating: 5,
      comment: "Great location and excellent service. Will definitely stay here again on my next visit."
    },
    {
      name: "Emma Wilson",
      rating: 5,
      comment: "Beautiful apartments with stunning views. The staff was incredibly helpful and friendly."
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSlider onBookNow={() => setIsBookingModalOpen(true)} />

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Why Choose Peakline?</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Experience luxury, comfort, and convenience in the heart of Dar es Salaam. Our modern apartments 
              offer everything you need for a perfect stay.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {amenities.map((amenity, index) => {
              const Icon = amenity.icon;
              return (
                <motion.div
                  key={amenity.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-card transition-all duration-300 group">
                    <CardHeader className="text-center">
                      <div className="mx-auto mb-4 w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                        <Icon className="w-8 h-8 text-accent" />
                      </div>
                      <CardTitle className="text-xl">{amenity.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-center text-base">
                        {amenity.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">What Our Guests Say</h2>
            <p className="text-xl text-muted-foreground">
              Don't just take our word for it - hear from our satisfied guests
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-accent text-accent" />
                      ))}
                    </div>
                    <p className="text-muted-foreground mb-4 italic">"{testimonial.comment}"</p>
                    <p className="font-semibold">- {testimonial.name}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-luxury-gradient text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Book Your Stay?</h2>
            <p className="text-xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
              Join thousands of satisfied guests who have made Peakline Apartments their home away from home.
            </p>
            <Button 
              variant="cta" 
              size="xl" 
              onClick={() => setIsBookingModalOpen(true)}
              className="shadow-glow hover:shadow-elegant"
            >
              Book Your Apartment Now
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Booking Modal */}
      <BookingModal 
        isOpen={isBookingModalOpen} 
        onClose={() => setIsBookingModalOpen(false)} 
      />
    </div>
  );
};

export default Index;
