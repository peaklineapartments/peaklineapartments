import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Building, Users, Star, Award, Heart, Shield } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Building, value: '6', label: 'Premium Apartments' },
    { icon: Users, value: '500+', label: 'Happy Guests' },
    { icon: Star, value: '4.9', label: 'Average Rating' },
    { icon: Award, value: '3', label: 'Years of Excellence' }
  ];

  const values = [
    {
      icon: Heart,
      title: 'Hospitality',
      description: 'We treat every guest like family, ensuring comfort and care throughout your stay.'
    },
    {
      icon: Star,
      title: 'Quality',
      description: 'Only the finest furnishings, amenities, and services meet our high standards.'
    },
    {
      icon: Shield,
      title: 'Security',
      description: '24/7 security and safety measures to give you complete peace of mind.'
    }
  ];

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-luxury-gradient bg-clip-text text-transparent">
            About Peakline Apartments
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover our story, values, and commitment to providing exceptional accommodation 
            experiences in the heart of Dar es Salaam.
          </p>
        </motion.div>

        {/* Introduction */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <Card className="overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="aspect-[4/3] lg:aspect-auto">
                <img
                  src="https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&q=80"
                  alt="Peakline Apartments Building"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <Badge className="w-fit mb-4">Our Story</Badge>
                <h2 className="text-3xl font-bold mb-6">Welcome to Peakline Apartments</h2>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    Founded with a vision to redefine hospitality in Dar es Salaam, Peakline Apartments 
                    has been providing exceptional accommodation experiences since 2021. We believe that 
                    every traveler deserves a home away from home.
                  </p>
                  <p>
                    Our carefully curated collection of apartments combines modern luxury with authentic 
                    Tanzanian warmth. From business travelers to vacation seekers, we've hosted guests 
                    from around the world who have come to appreciate our attention to detail and 
                    personalized service.
                  </p>
                  <p>
                    Located in the vibrant heart of Dar es Salaam, our apartments offer the perfect 
                    base for exploring the city's rich culture, business opportunities, and coastal beauty.
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </motion.section>

        {/* Stats */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="mx-auto mb-4 w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center">
                    <Icon className="w-8 h-8 text-accent" />
                  </div>
                  <div className="text-3xl font-bold mb-2">{stat.value}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </motion.div>
              );
            })}
          </div>
        </motion.section>

        {/* Values */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Values</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do at Peakline Apartments
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full text-center hover:shadow-card transition-all duration-300">
                    <CardHeader>
                      <div className="mx-auto mb-4 w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center">
                        <Icon className="w-8 h-8 text-accent" />
                      </div>
                      <CardTitle className="text-xl">{value.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base">
                        {value.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.section>

        {/* Team Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <Card className="bg-muted/50">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl font-bold mb-6">Meet Our Team</h2>
              <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                Our dedicated team of hospitality professionals is committed to making your stay 
                exceptional. From our front desk staff to our housekeeping team, every member is 
                passionate about delivering outstanding service.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                <div className="space-y-2">
                  <div className="w-24 h-24 bg-accent/10 rounded-full mx-auto flex items-center justify-center">
                    <Users className="w-12 h-12 text-accent" />
                  </div>
                  <h3 className="font-semibold">Management Team</h3>
                  <p className="text-sm text-muted-foreground">
                    Experienced leaders ensuring operational excellence
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="w-24 h-24 bg-accent/10 rounded-full mx-auto flex items-center justify-center">
                    <Heart className="w-12 h-12 text-accent" />
                  </div>
                  <h3 className="font-semibold">Guest Services</h3>
                  <p className="text-sm text-muted-foreground">
                    Friendly staff dedicated to your comfort and satisfaction
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="w-24 h-24 bg-accent/10 rounded-full mx-auto flex items-center justify-center">
                    <Shield className="w-12 h-12 text-accent" />
                  </div>
                  <h3 className="font-semibold">Maintenance & Security</h3>
                  <p className="text-sm text-muted-foreground">
                    Ensuring safety, cleanliness, and comfort 24/7
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Mission Statement */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center bg-luxury-gradient text-primary-foreground rounded-lg p-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Mission</h2>
          <p className="text-xl max-w-4xl mx-auto leading-relaxed">
            To provide exceptional short-term accommodation that combines the comfort of home 
            with the luxury of a premium hotel experience. We strive to exceed our guests' 
            expectations through personalized service, modern amenities, and genuine hospitality 
            that reflects the warm spirit of Tanzania.
          </p>
        </motion.section>

        {/* Placeholder for Future Content */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <Card className="border-dashed border-2 border-muted-foreground/30">
            <CardContent className="p-12 text-center">
              <Building className="w-16 h-16 text-muted-foreground/50 mx-auto mb-6" />
              <h3 className="text-xl font-semibold mb-4 text-muted-foreground">More to Come</h3>
              <p className="text-muted-foreground">
                We're constantly evolving and growing. Check back here for updates about our 
                company history, achievements, and exciting future plans.
              </p>
            </CardContent>
          </Card>
        </motion.section>
      </div>
    </div>
  );
};

export default About;