import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Eye, Bed, Users, Square, X, RotateCw, Move3D } from 'lucide-react';

const Gallery = () => {
  const [selectedApartment, setSelectedApartment] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [rotation, setRotation] = useState(0);

  // This would typically come from your backend or CMS
  const apartments = [
    {
      id: 'A1',
      name: 'Apartment A1',
      type: '2-Bedroom Luxury',
      size: '850 sq ft',
      capacity: '4 guests',
      price: '$60/night',
      images: [
        'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=800&q=80',
        'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=800&q=80',
        'https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&q=80'
      ],
      mainImage: 'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=800&q=80',
      description: 'Luxury 2-bedroom apartment with panoramic city views and modern amenities.'
    },
    {
      id: 'A2',
      name: 'Apartment A2',
      type: '2-Bedroom Modern',
      size: '820 sq ft',
      capacity: '4 guests',
      price: '$60/night',
      images: [
        'https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=800&q=80',
        'https://images.unsplash.com/photo-1472396961693-142e6e269027?w=800&q=80',
        'https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&q=80'
      ],
      mainImage: 'https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=800&q=80',
      description: 'Modern 2-bedroom apartment with elegant design and private balcony.'
    },
    {
      id: 'A3',
      name: 'Apartment A3',
      type: '2-Bedroom Garden View',
      size: '860 sq ft',
      capacity: '4 guests',
      price: '$60/night',
      images: [
        'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=800&q=80',
        'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=800&q=80',
        'https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=800&q=80'
      ],
      mainImage: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=800&q=80',
      description: 'Spacious 2-bedroom apartment overlooking beautiful garden spaces.'
    },
    {
      id: 'B1',
      name: 'Apartment B1',
      type: '2-Bedroom Suite',
      size: '900 sq ft',
      capacity: '4 guests',
      price: '$60/night',
      images: [
        'https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&q=80',
        'https://images.unsplash.com/photo-1472396961693-142e6e269027?w=800&q=80',
        'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=800&q=80'
      ],
      mainImage: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&q=80',
      description: 'Premium 2-bedroom suite with luxury finishes and spacious layout.'
    },
    {
      id: 'B2',
      name: 'Apartment B2',
      type: '2-Bedroom Terrace',
      size: '880 sq ft',
      capacity: '4 guests',
      price: '$60/night',
      images: [
        'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=800&q=80',
        'https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=800&q=80',
        'https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&q=80'
      ],
      mainImage: 'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=800&q=80',
      description: 'Elegant 2-bedroom apartment with private terrace and modern amenities.'
    },
    {
      id: 'B3',
      name: 'Apartment B3',
      type: '1-Bedroom Cozy',
      size: '550 sq ft',
      capacity: '2 guests',
      price: '$40/night',
      images: [
        'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=800&q=80',
        'https://images.unsplash.com/photo-1472396961693-142e6e269027?w=800&q=80',
        'https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=800&q=80'
      ],
      mainImage: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=800&q=80',
      description: 'Cozy 1-bedroom apartment perfect for couples or solo travelers.'
    }
  ];

  const handle360View = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setRotation(0);
  };

  const rotateImage = () => {
    setRotation(prev => prev + 90);
  };

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-luxury-gradient bg-clip-text text-transparent">
            Apartment Gallery
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Explore our beautifully designed apartments. Each unit is carefully crafted to provide 
            comfort, style, and all the amenities you need for a perfect stay.
          </p>
        </motion.div>

        {/* Apartment Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {apartments.map((apartment, index) => (
            <motion.div
              key={apartment.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden hover:shadow-card transition-all duration-300 group">
                {/* Main Image */}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={apartment.mainImage}
                    alt={apartment.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant="secondary" className="bg-background/90 text-foreground">
                      {apartment.id}
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-accent text-accent-foreground font-semibold">
                      {apartment.price}
                    </Badge>
                  </div>
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
                </div>

                {/* Content */}
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2">{apartment.name}</h3>
                  <p className="text-muted-foreground mb-4">{apartment.description}</p>
                  
                  {/* Details */}
                  <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                    <div className="flex items-center">
                      <Bed className="w-4 h-4 mr-2 text-accent" />
                      <span>{apartment.type}</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-2 text-accent" />
                      <span>{apartment.capacity}</span>
                    </div>
                    <div className="flex items-center">
                      <Square className="w-4 h-4 mr-2 text-accent" />
                      <span>{apartment.size}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => setSelectedApartment(apartment.id)}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View All Photos
                    </Button>
                    <Button
                      variant="gold"
                      size="sm"
                      className="w-full"
                      onClick={() => handle360View(apartment.mainImage)}
                    >
                      <Move3D className="w-4 h-4 mr-2" />
                      Get a 360° View
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Gallery Modal */}
        <Dialog open={!!selectedApartment} onOpenChange={() => setSelectedApartment(null)}>
          <DialogContent className="max-w-6xl max-h-[90vh]">
            {selectedApartment && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold">
                    {apartments.find(apt => apt.id === selectedApartment)?.name}
                  </h2>
                  <Button variant="ghost" size="icon" onClick={() => setSelectedApartment(null)}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[70vh] overflow-y-auto">
                  {apartments.find(apt => apt.id === selectedApartment)?.images.map((image, index) => (
                    <div key={index} className="relative aspect-[4/3] overflow-hidden rounded-lg">
                      <img
                        src={image}
                        alt={`View ${index + 1}`}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300 cursor-pointer"
                        onClick={() => handle360View(image)}
                      />
                      <div className="absolute inset-0 hover:bg-black/10 transition-colors duration-300" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* 360 View Modal */}
        <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
          <DialogContent className="max-w-4xl">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">360° View</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={rotateImage}>
                    <RotateCw className="w-4 h-4 mr-2" />
                    Rotate
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => setSelectedImage(null)}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              {selectedImage && (
                <div className="relative aspect-video overflow-hidden rounded-lg bg-black">
                  <img
                    src={selectedImage}
                    alt="360° View"
                    className="w-full h-full object-contain transition-transform duration-500"
                    style={{ transform: `rotate(${rotation}deg)` }}
                  />
                </div>
              )}
              
              <p className="text-sm text-muted-foreground text-center">
                Use the rotate button to get different angles of the apartment. 
                Click and drag to explore the space virtually.
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default Gallery;