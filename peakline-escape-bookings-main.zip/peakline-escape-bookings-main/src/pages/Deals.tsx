import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Percent, Gift, Star, Phone } from 'lucide-react';

const Deals = () => {
  const currentDeals = [
    {
      id: 1,
      title: "Extended Stay Discount",
      description: "Save 20% on stays of 7 nights or longer",
      discount: "20%",
      validUntil: "March 31, 2024",
      terms: "Minimum 7 nights stay required. Cannot be combined with other offers.",
      type: "Extended Stay",
      featured: true
    },
    {
      id: 2,
      title: "Early Bird Special",
      description: "Book 30 days in advance and save 15%",
      discount: "15%",
      validUntil: "December 31, 2024",
      terms: "Must book at least 30 days before check-in date.",
      type: "Early Booking",
      featured: false
    },
    {
      id: 3,
      title: "Weekend Getaway",
      description: "Special rates for Friday-Sunday stays",
      discount: "10%",
      validUntil: "Ongoing",
      terms: "Valid for weekend stays only (Friday to Sunday).",
      type: "Weekend",
      featured: false
    }
  ];

  const seasonalOffers = [
    {
      title: "Low Season Rates",
      description: "Enjoy reduced rates during our low season periods",
      period: "May - July, September - November",
      discount: "Up to 25% off"
    },
    {
      title: "Holiday Packages",
      description: "Special packages for holidays and festivals",
      period: "During major holidays",
      discount: "Custom packages available"
    }
  ];

  const handleBookNow = () => {
    // This would typically open the booking modal or navigate to booking
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCallForDetails = () => {
    window.open('tel:+255715245377', '_self');
  };

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-luxury-gradient bg-clip-text text-transparent">
            Exclusive Deals & Offers
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Take advantage of our special offers and save on your next stay at Peakline Apartments. 
            Limited time deals and seasonal discounts available.
          </p>
        </motion.div>

        {/* Current Deals */}
        <section className="mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-8 text-center"
          >
            Current Offers
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {currentDeals.map((deal, index) => (
              <motion.div
                key={deal.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`h-full transition-all duration-300 hover:shadow-card ${
                  deal.featured ? 'ring-2 ring-accent shadow-glow' : ''
                }`}>
                  <CardHeader>
                    <div className="flex justify-between items-start mb-2">
                      <Badge variant={deal.featured ? "default" : "secondary"} className="mb-2">
                        {deal.type}
                      </Badge>
                      {deal.featured && (
                        <div className="flex items-center">
                          <Star className="w-4 h-4 fill-accent text-accent mr-1" />
                          <span className="text-sm font-medium text-accent">Featured</span>
                        </div>
                      )}
                    </div>
                    <CardTitle className="text-xl mb-2">{deal.title}</CardTitle>
                    <div className="text-3xl font-bold text-accent mb-2">
                      {deal.discount} OFF
                    </div>
                    <CardDescription className="text-base">
                      {deal.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4 mr-2" />
                        Valid until: {deal.validUntil}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <strong>Terms:</strong> {deal.terms}
                      </div>
                    </div>
                    <Button 
                      className="w-full" 
                      variant={deal.featured ? "cta" : "gold"}
                      onClick={handleBookNow}
                    >
                      Book Now
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Seasonal Offers */}
        <section className="mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-8 text-center"
          >
            Seasonal Offers
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {seasonalOffers.map((offer, index) => (
              <motion.div
                key={offer.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-card transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-xl mb-2">{offer.title}</CardTitle>
                    <CardDescription className="text-base">
                      {offer.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="w-4 h-4 mr-2" />
                        {offer.period}
                      </div>
                      <div className="flex items-center text-accent font-semibold">
                        <Percent className="w-4 h-4 mr-2" />
                        {offer.discount}
                      </div>
                    </div>
                    <Button variant="outline" className="w-full" onClick={handleCallForDetails}>
                      <Phone className="w-4 h-4 mr-2" />
                      Call for Details
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Contact for Custom Deals */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center bg-muted/50 rounded-lg p-12"
        >
          <Gift className="w-16 h-16 text-accent mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Looking for Something Special?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Planning a special event, group stay, or extended vacation? Contact us for custom packages 
            and personalized deals tailored to your needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="cta" size="lg" onClick={handleCallForDetails}>
              <Phone className="w-5 h-5 mr-2" />
              Call +255715245377
            </Button>
            <Button variant="outline" size="lg" onClick={() => window.open('https://wa.me/255715245377', '_blank')}>
              WhatsApp Us
            </Button>
          </div>
        </motion.section>

        {/* Terms & Conditions */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <Card>
            <CardHeader>
              <CardTitle>Terms & Conditions</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground space-y-2">
              <p>• All offers are subject to availability and may be withdrawn at any time.</p>
              <p>• Discounts cannot be combined with other promotional offers unless specified.</p>
              <p>• Special rates are valid for new bookings only.</p>
              <p>• A deposit may be required to secure your booking.</p>
              <p>• Standard cancellation and refund policies apply.</p>
              <p>• Management reserves the right to modify terms and conditions.</p>
            </CardContent>
          </Card>
        </motion.section>
      </div>
    </div>
  );
};

export default Deals;