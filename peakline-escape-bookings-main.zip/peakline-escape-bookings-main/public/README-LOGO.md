# Peakline Logo

Please place the Peakline logo image as `peakline-logo.png` in the `/public` folder.

The logo should be:
- A white logo on transparent background for best visibility
- PNG format
- Reasonable size (recommend 300x100px or similar aspect ratio)

The current implementation in the navbar will:
- Display the logo at height 40px (h-10)
- Auto-adjust width to maintain aspect ratio
- Apply color filters for light/dark mode compatibility:
  - Light mode: Makes white logo appear dark (filter brightness-0 invert)
  - Dark mode: Shows original white logo (brightness-100 invert-0)